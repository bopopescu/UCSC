/*
CMPS 111
Winter 2017
Assignment 2
Erik Andersen (Team Captain)
Seongwoo Choi
Yuzhuang Chen
Michael Cardoza
write_test.c
*/

/*
Libraries
*/
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>


/*
cpuHog is our function to test if our kernel will crash when working on
big processes. It will work on a for loop, then a while, and "ending" on
a very big triple for loop. The last for loops will be sending its results
into a file.
 */
void cpuTest(){
  int testi = 0;
  int testj = 0;
  int wtrue = 0;
  FILE *f = fopen("testFile.txt", "w");

  for(int i = 0; i < 1000; i++){
    testi = testi + 1;
    printf("%d\n", testi);
    for(int j = 0; j < 100; j++){
      testj = testj + 1;
      printf("%d\n", testj);
    }
  }

  while(wtrue < 9999){
    printf("The current test number is %d\n", wtrue);
    wtrue += 1;
  }

  for(int i = 0; i < 100000; i++){
    for(int j = 0; j < 10000; j++){
      testi = testi - 2;
      for(int k = 0; k < 1000; k++){
        fprintf(f, "testi: %d\n", testi);
      }
    }
  }
}


/*
The main function will open input file and then read over the arguments and then write on
an output file.
*/
int main (int argc, char* argv[]) {
        char buffer[1024];
        int file_in = open(argv[1], O_RDONLY);
        int file_out = open(argv[2], O_WRONLY | O_CREAT, 0644);
        pid_t pid;
        ssize_t r;

        if(argc != 3){
          printf("You are missing some files.\n");
          return 1;
        }

        if(file_in == -1){
          perror(argv[1]);
        }

        switch(pid = fork()){
        case 0:
          for(int i = 0; i < 100; i++){
            while((r = read(file_in, buffer, sizeof(buffer))) > 0){
              write(file_out, buffer, r);
            }
          }
          break;
        case -1:
          break;
        default:
          wait(0);
          cpuTest();
          break;
        }
}
