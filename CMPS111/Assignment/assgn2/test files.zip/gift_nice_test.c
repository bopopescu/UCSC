#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>

int main(int argc, char* argv[]){
  pid_t pid;
  pid_t pid1;
  int ret;
  int pf = 0;
  int which = PRIO_PROCESS;

  /*
    execvp("cmd", what command is doing")
   */
  pid = fork();
  switch(pid){
  case 0:
    sleep(5);
    int tc = syscall(548,0,0);
    printf("Child's ticket count: %d\n", tc);
    break;
  case -1:
    break;
  default:
    pf = syscall(548,0,0);
    printf("Tickets before nice: %d\n", pf);
    nice(10);
    pf = syscall(548,100,pid);
    printf("Father's tickets after nice; %d\n", pf);
    break;

  }
}
