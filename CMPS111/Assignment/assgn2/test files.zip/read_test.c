/*
CMPS 111
Winter 2017
Assignment 2
Erik Andersen (Team Captain)
Seongwoo Choi
Yuzhuang Chen
Michael Cardoza
read_test.c
*/

/*
Libraries
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/syscall.h>
#include <sys/resource.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>

/*
Variables
*/
int i;
int n = 20;
int m = -20;
int ret = -1;
int which = PRIO_PROCESS;
int process;
int status;
int maximum;
int children;
int pf;
int tc;
int tickets = -1;
pid_t pid, nid;

/*
Nice function to compare the ticket count of a process
before and after applying the nice system call.
*/

/*
void niceFunction() {
  tickets = syscall(548,0,0);
  printf("\nThis is the original ticket count: %d\n", tickets);

  nice(n);
  tickets = syscall(548,0,0);
  printf("This is ticket count after a positive nice: %d\n", tickets);

  nice(m);
  tickets = syscall(548,0,0);
  printf("This is ticket count after a negative nice: %d\n\n", tickets);

  tickets = -1;
}

/*
giftFunction will be used to test 3 things:
1)It will use the 0,0 arguments to make sure we can see what the
ticket count is before anything is done.
2)It will then gift 100 tickets over to its child and display
the number of remaining tickets
3)It will try to give 111111 to its child, this will test to
show that when it tries to give tickets past its maximum it will
just display how many tickets it has.
*/
/*
void giftFunction(pid_t pid) {
  int gt = 0;

  gt = syscall(548,0,0);
  printf("Ticket count before gifting: %d\n", gt);

  gt = syscall(548,100,pid);
  printf("Ticket count after gifting: %d\n", gt);

  gt = syscall(548,111111,pid);
  printf("Ticket count after trying to gift more than max, %d\n", gt);
}
*/

/*
Main function goes down the pipe of child process
Similar to the second lab assignment.
*/
int main(int argc, char *argv[]) {
  int i;

/*Convert string to integer
Parses the C-string str interpreting its content as an integral number, which is returned as a value of type int.*/
  maximum = atoi (argv[1]);
  status = 0;
  children = 0;

  for (i =0; i < 10; i++) {
    switch(pid = fork()) {
    case 0:
      sleep(2);
      printf("Child fork %d PID: %d\n", children, nid = getpid());
      ++children;
      status = 0;

     // niceFunction();
      while (status < maximum) {
        ++status;
        if ((status % 100000) == 0 || (maximum - status) < 10){
          printf("%d Child Process: %d, %12d needs to process\n", getpid(), (maximum-status));
        }
      }
      break;

    case -1:
      printf("Child fork does not work here");
      perror("fork");
      exit(1);

    default :
      printf("Parent Process ID: %d\n", getpid());
      while(status < maximum){
        ++status;
        if (status % 1000 == 0 || (maximum - status) < 10){
          printf("%d Parent PID: %d, %12d to go\n", children, getpid(), (maximum - status));
      break;
    }
  }
}
}
}