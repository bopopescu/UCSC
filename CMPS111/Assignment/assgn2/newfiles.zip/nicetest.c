#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>

int main(int argc, char* argv[]){
  pid_t pid;
  pid_t pid1;
  int ret;
  int pf = 0;
  int which = PRIO_PROCESS;

  /*
    execvp("cmd", what command is doing")
   */
  pid = fork();
  switch(pid){
  case 0:
    sleep(5);
    break;
  case -1:
    break;
  default:
    nice(20);

    //ask erik if he wants it to look like this
    ret = nice(-10);

    //of if he wants it like this
    nice(-10);
    break;

  }
}
