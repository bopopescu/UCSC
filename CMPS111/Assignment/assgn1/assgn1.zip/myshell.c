#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <errno.h>

extern char **getline();

typedef struct node node;
struct node{
   char **command;
   char *input;
   char *output;
   node *next;
   bool background; 
};  

typedef struct job job;
struct job{
   int number;
   int *pid;
   char *status;
   char **args;
   job *next;
};

void ins_command(node *sample, char* command){
   int i = 0;
   assert(sample != NULL);
   while(sample->command[i] != NULL){
      i++;
   }
   sample->command[i] = command;
}

void clear(node *sample){
   assert(sample->command != NULL);
   int i = 0;
   while(sample->command[i] != NULL){
      sample->command[i] = NULL;
      i++;
   }
   sample->input = NULL;
   sample->output = NULL;
}

void red_output(node *sample){
   if(sample->output != NULL){
      int fil_d = open(sample->output, O_CREAT | O_RDWR, S_IRWXU);
      dup2(fil_d, 1);
      close(fil_d);
   }
}

void fork_rec(node *sample, job *thisjob){
   int pipefd[2];
   pipe(pipefd);
   pid_t child = fork();
   if(child < 0){
      perror("Fork failed.");
      exit(1);
   }
   if(child == 0){
      close(pipefd[1]);
      dup2(pipefd[0], 0);
      close(pipefd[0]);
      if(sample->next->next != NULL){ fork_rec(sample->next, thisjob);  
      }else{
          red_output(sample->next);
          execvp(sample->next->command[0], sample->next->command);
      }
   }else{
      close(pipefd[0]);
      dup2(pipefd[1], 1);
      close(pipefd[1]);
      int i = 0;
      // printf("%d", child);  
      while(child < thisjob->pid[i]) i++;
      thisjob->pid[i] = child;     
      execvp(sample->command[0], sample->command);
      int status;
      wait(&status);
   }
}

void print_jobs(job *thisjob){
   printf("[%d]    ", thisjob->number);
      printf("%d", thisjob->pid[0]);
   printf("    %s\n", thisjob->status);

}


int main() {
   int i;
   char **args;
   
   struct node *newnode = (struct node *) malloc(sizeof(struct node));
   struct job *newjob = (struct job *) malloc(sizeof(struct job));
   newnode->command = (char**)malloc(sizeof(char)*100);
   newnode->background = false;
   newjob->pid = (int*)malloc(sizeof(int)*100);
   int num = 1;
   while(1) {
      args = getline();
      if(num == 1){
         newjob->number = num;
         newjob->args = args;
         num++;
      }
      struct node *curr = newnode;
      for(i = 0; args[i] != NULL; i++) {
           if(strcmp(args[i], ">") == 0){
               i++;
               if(newnode->next == NULL) newnode->output = args[i];
               else curr->output = args[i]; 
           }else if(strcmp(args[i], "<") == 0){
               i++;
               if(newnode->next == NULL) newnode->input = args[i];
               else curr->input = args[i]; 
           }else if(strcmp(args[i], "|") == 0){ 
               struct node *temp = (struct node *) malloc(sizeof(struct node));
               temp->command = (char**)malloc(sizeof(char)*100);
               if(newnode->next == NULL) newnode->next = temp;
               else curr->next = temp; 
               curr = temp;
           }else if(strcmp(args[i], "&") == 0){
               newnode->background = true; 
           }else{
               if(newnode->next == NULL) ins_command(newnode, args[i]);
               else ins_command(curr, args[i]);
           }
         if(strcmp(args[i], "exit") == 0) exit(1);
         if(strcmp(args[i], "jobs") == 0) print_jobs(newjob);
      }
         pid_t proc = fork();
         if(proc == -1){
            perror("Fork error");
            exit(1);

         }
         if(proc == 0){
            if(newnode->input != NULL){
               int fil_i = open(newnode->input, O_RDWR);
               if(fil_i == -1){
                  perror("Error: ");
                  _exit(1);
               }
               dup2(fil_i, 0);
               close(fil_i);
            }
            if(newnode->next != NULL){
               fork_rec(newnode, newjob);
            }else{
               red_output(newnode);
               execvp(newnode->command[0], newnode->command);
            }
         }
         else{
            newjob->pid[0] = proc; 
            int status;
            newjob->status = "Running";
            if(newnode->background == true) exit(0);
            wait(&status);
            newjob->status = "Done";
         }
      num++;
      clear(newnode);
      }
      for(node *this = newnode; this != NULL; this = this->next){
         free(this->command);
         free(this);
      } 
}
