/*
Seongwoo Choi
scho29
1368039
CMPS180 - Winter 2017
*/

CREATE INDEX ON Persons(HouseID, ApartmentNumber);