CREATE VIEW Home_Landlords AS
SELECT P.SSN, L.LandlordID, P.HouseID, P.ApartmentNumber
FROM Persons P, Landlords L, Ownerships O
WHERE P.HouseID = O.HouseID AND O.LandlordID = L.LandlordID AND L.OwnerSSN = P.SSN;