-- All the following tests (INSERT and UPDATE statements) are examples, other tests are also correct. Any test that is correct will be admitted.

--Violations for HouseID

INSERT INTO Persons VALUES (801039501,'John Smith', 10000, 1, 20000.00);

INSERT INTO Ownerships VALUES (300,5000,'01/01/1970',10000.00);

INSERT INTO Tenants VALUES (5000,1,664067824,'05/10/2011','04/15/2017',6200.10,'01/01/2017',false);

--General constraints unit tests
--1
UPDATE Ownerships 
SET PropertyTax = 10000.00 
WHERE LandlordID = 100 AND HouseID = 500;

UPDATE Ownerships 
SET PropertyTax = -1.0 
WHERE LandlordID = 100 AND HouseID = 500;

--2
UPDATE Tenants
SET Rent = 3000.00
WHERE HouseID = 200 AND ApartmentNumber = 1;

UPDATE Tenants
SET Rent = 0.0
WHERE HouseID = 200 AND ApartmentNumber = 1;

--3
UPDATE Tenants
SET LeaseExpirationDate = '01/01/2017'
WHERE HouseID = 200 AND ApartmentNumber = 3;

UPDATE Tenants
SET LeaseExpirationDate = '01/01/2010'
WHERE HouseID = 200 AND ApartmentNumber = 3;

--4
UPDATE Tenants
SET LastRentPaidDate = current_date, RentOverdue = false
WHERE HouseID = 200 AND ApartmentNumber = 1;

UPDATE Tenants
SET LastRentPaidDate = current_date, RentOverdue = true
WHERE HouseID = 200 AND ApartmentNumber = 1;