-- The UPDATE operation handles the tuples in NewRentPayments that have matching primary keys in Tenants
UPDATE Tenants
SET LastRentPaidDate = DatePaid, RentOverdue = false
FROM NewRentPayments
WHERE Tenants.HouseID = NewRentPayments.HouseID
      AND Tenants.ApartmentNumber = NewRentPayments.ApartmentNumber
      AND Tenants.Rent = NewRentPayments.Rent 
      AND Tenants.LeaseTenantSSN = NewRentPayments.LeaseTenantSSN;

-- The INSERT operation handles the tuples in NewRentPayments that do not have matching primary keys in Tenants
INSERT INTO Tenants(HouseID, ApartmentNumber, LeaseTenantSSN, LeaseStartDate, LeaseExpirationDate, Rent, LastRentPaidDate, RentOverdue)
SELECT HouseID, ApartmentNumber, LeaseTenantSSN, current_date, NULL, Rent, DatePaid, false
FROM NewRentPayments
WHERE NOT EXISTS (
    SELECT * FROM Tenants WHERE Tenants.HouseID = NewRentPayments.HouseID AND 
             Tenants.ApartmentNumber = NewRentPayments.ApartmentNumber 
  );

-- An equivalent INSERT statement with the use of NOT IN is below
INSERT INTO Tenants(HouseID, ApartmentNumber, LeaseTenantSSN, LeaseStartDate, LeaseExpirationDate, Rent, LastRentPaidDate, RentOverdue)
SELECT HouseID, ApartmentNumber, LeaseTenantSSN, current_date, NULL, Rent, DatePaid, false
FROM NewRentPayments
WHERE (HouseID, ApartmentNumber) NOT IN (
    SELECT HouseID,ApartmentNumber FROM Tenants
  );

-- The list of attributes after Tenants is optional