SELECT P.name, T.rent
FROM Home_Landlords HL, Persons P, Tenants T
WHERE P.SSN = HL.SSN AND T.LeaseTenantSSN = P.SSN AND T.RentOverDue;

-- Use of DISTINCT is not correct, since a Landlord might be the LeaseTenant
-- on two houses that have the same rent. This is unlikely to happen, but possible.

-- Output on load data before deletions:
--              name              |  rent   ----------------------------------+----------- Robert Johnson                 | 1802.40-- Alex Jones                     | 2201.10-- Juan Rodriguez                 | 3104.10-- Juan Rodriguez                 | 2310.50--(4 rows)

DELETE FROM Tenants
WHERE HouseID = 1100 AND ApartmentNumber = 2;

DELETE FROM Tenants
WHERE HouseID = 1000 AND ApartmentNumber = 2;

-- Output on load data after deletions:
--              name              |  rent   ----------------------------------+----------- Robert Johnson                 | 1802.40-- Juan Rodriguez                 | 3104.10--(2 rows)