ALTER TABLE Ownerships ADD CHECK(PropertyTax >=0);

ALTER TABLE Tenants ADD CONSTRAINT positive_rent CHECK(Rent > 0);

ALTER TABLE Tenants ADD CHECK(LeaseExpirationDate > LeaseStartDate OR LeaseExpirationDate IS NULL);

ALTER TABLE Tenants ADD CHECK(LastRentPaidDate <> current_date OR NOT RentOverdue);