CREATE SCHEMA Lab1;
ALTER ROLE scho29 SET SEARCH_PATH to Lab1;
SHOW SEARCH_PATH;

CREATE TABLE Persons (
SSN int,
Name char(30),
HouseID int,
ApartmentNumber int,
Salary decimal(7,2),
PRIMARY KEY (SSN)
);

CREATE TABLE Houses (
HouseID int,
HouseAddress char(40),
ApartmentCount int,
Color char(40),
PRIMARY KEY (HouseID)
);

CREATE TABLE Landlords (
LandlordID int,
OwnerSSN int
LandlordAddress char(40),
PRIMARY KEY (LandlordID)
);

CREATE TABLE Ownerships 
LandlordID int,
HouseID int,
PurchaseDate date,
PropertyTax decimal(7,2),
PRIMARY KEY (LandlordID, HouseID)
);

CREATE TABLE Tenants (
HouseID int,
ApartmentNumber int,
LeaseTenantSSN int,
LeaseStartDate date,
LeaseExpirationDate date,
Rent decimal(7,2),
LastRentPaidDate date,
RentOverdue boolean,
PRIMARY KEY (HouseID, ApartmentNumber)
);
