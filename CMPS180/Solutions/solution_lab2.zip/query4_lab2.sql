SELECT DISTINCT P.product_id, P.name
FROM Products P, Sales S
WHERE P.product_id = S.product_id AND purchase_date = '07/04/2016';

--Alternatively, with IN:
--
--SELECT DISTINCT P.product_id, P.name
--FROM Products P
--WHERE P.product_id IN (SELECT product_id FROM Sales WHERE purchase_date = '07/04/2016');