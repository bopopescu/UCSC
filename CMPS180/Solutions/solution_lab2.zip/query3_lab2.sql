SELECT C.name, store_id, C.address
FROM Stores, Customers C
WHERE manager = C.name;