SELECT name, address
FROM Customers
WHERE email IS NULL;