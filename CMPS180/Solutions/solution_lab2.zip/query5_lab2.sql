SELECT S.customer_id, S.purchase_date
FROM Stores St, Sales S, Products P
WHERE S.product_id= P.product_id AND P.manufacturer = 'Kellogg' AND St.store_id = S.store_id AND St.manager = 'George Jetson' AND S.price > 49.98 AND shipped = true;


--Some students may have used a numeric operation either dividing or multiplying the 
--price by quantity in the inequality condition S.price > 49.98 in the WHERE clause. 
--We will not remove points for this (provided the rest of the query is correct) as
--there was a double ambiguity in the assignment text (on whether the price attribute in
--Sales records full sales price or unit price), and on the meaning of 
--the query description itself (on whether price refers to the unit of the product 
--or the full sale).

--Other valid variations of the query exist, as in the example below that 
--uses IN twice

--SELECT s.customer_id, s.purchase_date
--FROM Sales s
--WHERE s.price > 49.98
--   AND s.shipped = TRUE
--   AND s.product_id IN (SELECT p.product_id
--               FROM Products p
--               WHERE p.manufacturer = 'Kellogg'
--               )
--   AND s.store_id IN (SELECT st.store_id
--           FROM Stores st
--           WHERE st.manager = 'George Jetson'
--           );