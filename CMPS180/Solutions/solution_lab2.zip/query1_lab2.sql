SELECT name
FROM Stores
WHERE manager = 'Shel Finkelstein';