SELECT P.name, P.manufacturer, S.purchase_date, SUM(quantity)
FROM Products P, Sales S
WHERE S.product_id = P.product_id
GROUP BY P.name, P.manufacturer, S.purchase_date;

--You are also free to use an alias for the aggregate e.g 
--SELECT P.name, P.manufacturer, S.purchase_date, SUM(quantity) AS total_quantity